# quora-question-pairs
A NLP project to find weather given 2 questions are same are not semantically speaking.

Dataset Link - https://www.kaggle.com/c/quora-question-pairs
